﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestEx3.Models
{
    // Order.cs
public class Order
    {
        public int OrderId { get; set; }
        public int Custid { get; set; }
    }
}
