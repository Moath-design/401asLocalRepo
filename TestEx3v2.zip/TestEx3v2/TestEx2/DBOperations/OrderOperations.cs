﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using TestEx3.Models;

namespace TestEx3.DBOperations
{
    // OrderOperations.cs
    public class OrderOperations
    {
        private readonly DataAccess dataAccess = new DataAccess();

        public void AddOrder(Order order)
        {
            string query = "CALL AddOrder(@p_Custid)";
            MySqlCommand command = new MySqlCommand(query);

            command.Parameters.AddWithValue("@p_Custid", order.Custid);

            dataAccess.ExecuteNonQuery(command);
        }

        public DataTable GetOrders()
        {
            string query = "CALL GetOrders()";
            return dataAccess.ExecuteQuery(query);
        }

        public void UpdateOrder(Order order)
        {
            string query = "CALL UpdateOrder(@p_orderid, @p_Custid)";
            MySqlCommand command = new MySqlCommand(query);

            command.Parameters.AddWithValue("@p_orderid", order.OrderId);
            command.Parameters.AddWithValue("@p_Custid", order.Custid);

            dataAccess.ExecuteNonQuery(command);
        }

        public void DeleteOrder(int orderId)
        {
            string query = "CALL DeleteOrder(@p_orderid)";
            MySqlCommand command = new MySqlCommand(query);

            command.Parameters.AddWithValue("@p_orderid", orderId);

            dataAccess.ExecuteNonQuery(command);
        }
    }

}
