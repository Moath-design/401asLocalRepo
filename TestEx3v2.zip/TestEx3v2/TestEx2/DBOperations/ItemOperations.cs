﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using TestEx3.Models;

namespace TestEx3.DBOperations;

// ItemOperations.cs
public class ItemOperations
{
    private readonly DataAccess dataAccess = new DataAccess();

    public void AddItem(Item item)
    {
        string query = "CALL AddItem(@p_name, @p_description, @p_price)";
        MySqlCommand command = new MySqlCommand(query);

        command.Parameters.AddWithValue("@p_name", item.Name);
        command.Parameters.AddWithValue("@p_description", item.Description);
        command.Parameters.AddWithValue("@p_price", item.Price);

        dataAccess.ExecuteNonQuery(command);
    }

    public DataTable GetItems()
    {
        string query = "CALL GetItems()";
        return dataAccess.ExecuteQuery(query);
    }

    public void UpdateItem(Item item)
    {
        string query = "CALL UpdateItem(@p_id, @p_name, @p_description, @p_price)";
        MySqlCommand command = new MySqlCommand(query);

        command.Parameters.AddWithValue("@p_id", item.ItemId);
        command.Parameters.AddWithValue("@p_name", item.Name);
        command.Parameters.AddWithValue("@p_description", item.Description);
        command.Parameters.AddWithValue("@p_price", item.Price);

        dataAccess.ExecuteNonQuery(command);
    }

    public void DeleteItem(int itemId)
    {
        string query = "CALL DeleteItem(@p_id)";
        MySqlCommand command = new MySqlCommand(query);

        command.Parameters.AddWithValue("@p_id", itemId);

        dataAccess.ExecuteNonQuery(command);
    }
}
