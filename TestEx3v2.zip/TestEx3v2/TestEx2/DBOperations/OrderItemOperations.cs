﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using TestEx3.Models;

namespace TestEx3.DBOperations
{
    // OrderItemOperations.cs
    public class OrderItemOperations
    {
        private readonly DataAccess dataAccess = new DataAccess();

        public void AddOrderItem(OrderItem orderItem)
        {
            string query = "CALL AddOrderItem(@p_orderid, @p_itemid, @p_quantity)";
            MySqlCommand command = new MySqlCommand(query);

            command.Parameters.AddWithValue("@p_orderid", orderItem.OrderId);
            command.Parameters.AddWithValue("@p_itemid", orderItem.ItemId);
            command.Parameters.AddWithValue("@p_quantity", orderItem.Quantity);

            dataAccess.ExecuteNonQuery(command);
        }

        public DataTable GetOrderItems()
        {
            string query = "CALL GetOrderItems()";
            return dataAccess.ExecuteQuery(query);
        }

        public void UpdateOrderItem(OrderItem orderItem)
        {
            string query = "CALL UpdateOrderItem(@p_orderid, @p_itemid, @p_quantity)";
            MySqlCommand command = new MySqlCommand(query);

            command.Parameters.AddWithValue("@p_orderid", orderItem.OrderId);
            command.Parameters.AddWithValue("@p_itemid", orderItem.ItemId);
            command.Parameters.AddWithValue("@p_quantity", orderItem.Quantity);

            dataAccess.ExecuteNonQuery(command);
        }

        public void DeleteOrderItem(int orderId, int itemId)
        {
            string query = "CALL DeleteOrderItem(@p_orderid, @p_itemid)";
            MySqlCommand command = new MySqlCommand(query);

            command.Parameters.AddWithValue("@p_orderid", orderId);
            command.Parameters.AddWithValue("@p_itemid", itemId);

            dataAccess.ExecuteNonQuery(command);
        }
    }

}
