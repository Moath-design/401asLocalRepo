﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using TestEx3.Models;

namespace TestEx3.DBOperations
{
    // CustomerOperations.cs


    public class CustomerOperations
    {
        private readonly DataAccess dataAccess = new DataAccess();

        public void AddCustomer(Customer customer)
        {
            string query = "CALL AddCustomer(@p_firstname, @p_lastname, @p_email, @p_dateofbirth)";
            MySqlCommand command = new MySqlCommand(query);

            command.Parameters.AddWithValue("@p_firstname", customer.FirstName);
            command.Parameters.AddWithValue("@p_lastname", customer.LastName);
            command.Parameters.AddWithValue("@p_email", customer.Email);
            command.Parameters.AddWithValue("@p_dateofbirth", customer.DateOfBirth.ToString("yyyy-MM-dd"));

            dataAccess.ExecuteNonQuery(command);
        }

        public DataTable GetCustomers()
        {
            string query = "CALL GetCustomers()";
            return dataAccess.ExecuteQuery(query);
        }

        public void UpdateCustomer(Customer customer)
        {
            string query = "CALL UpdateCustomer(@p_id, @p_firstname, @p_lastname, @p_email, @p_dateofbirth)";
            MySqlCommand command = new MySqlCommand(query);

            command.Parameters.AddWithValue("@p_id", customer.Id);
            command.Parameters.AddWithValue("@p_firstname", customer.FirstName);
            command.Parameters.AddWithValue("@p_lastname", customer.LastName);
            command.Parameters.AddWithValue("@p_email", customer.Email);
            command.Parameters.AddWithValue("@p_dateofbirth", customer.DateOfBirth.ToString("yyyy-MM-dd"));

            dataAccess.ExecuteNonQuery(command);
        }

        public void DeleteCustomer(int customerId)
        {
            string query = "CALL DeleteCustomer(@p_id)";
            MySqlCommand command = new MySqlCommand(query);

            command.Parameters.AddWithValue("@p_id", customerId);

            dataAccess.ExecuteNonQuery(command);
        }

    }

}
