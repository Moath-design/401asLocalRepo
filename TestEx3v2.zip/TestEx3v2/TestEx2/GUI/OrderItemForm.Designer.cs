﻿namespace TestEx3
{
    partial class OrderItemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textOrdId = new TextBox();
            textItemId = new TextBox();
            label2 = new Label();
            textQuantity = new TextBox();
            label3 = new Label();
            btnADDOrderItem = new Button();
            btnUPDATEOrderItem = new Button();
            btnDELETEOrderItem = new Button();
            dataGridViewOrderItem = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewOrderItem).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(101, 128);
            label1.Name = "label1";
            label1.Size = new Size(110, 32);
            label1.TabIndex = 0;
            label1.Text = "Order ID:";
            // 
            // textOrdId
            // 
            textOrdId.Location = new Point(269, 128);
            textOrdId.Name = "textOrdId";
            textOrdId.Size = new Size(200, 39);
            textOrdId.TabIndex = 1;
            // 
            // textItemId
            // 
            textItemId.Location = new Point(269, 209);
            textItemId.Name = "textItemId";
            textItemId.Size = new Size(200, 39);
            textItemId.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(101, 209);
            label2.Name = "label2";
            label2.Size = new Size(97, 32);
            label2.TabIndex = 2;
            label2.Text = "Item ID:";
            // 
            // textQuantity
            // 
            textQuantity.Location = new Point(269, 303);
            textQuantity.Name = "textQuantity";
            textQuantity.Size = new Size(200, 39);
            textQuantity.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(101, 303);
            label3.Name = "label3";
            label3.Size = new Size(111, 32);
            label3.TabIndex = 4;
            label3.Text = "Quantity:";
            // 
            // btnADDOrderItem
            // 
            btnADDOrderItem.Location = new Point(1156, 543);
            btnADDOrderItem.Name = "btnADDOrderItem";
            btnADDOrderItem.Size = new Size(150, 46);
            btnADDOrderItem.TabIndex = 6;
            btnADDOrderItem.Text = "ADD";
            btnADDOrderItem.UseVisualStyleBackColor = true;
            btnADDOrderItem.Click += btnADDOrderItem_Click;
            // 
            // btnUPDATEOrderItem
            // 
            btnUPDATEOrderItem.Location = new Point(871, 543);
            btnUPDATEOrderItem.Name = "btnUPDATEOrderItem";
            btnUPDATEOrderItem.Size = new Size(150, 46);
            btnUPDATEOrderItem.TabIndex = 7;
            btnUPDATEOrderItem.Text = "UPDATE";
            btnUPDATEOrderItem.UseVisualStyleBackColor = true;
            btnUPDATEOrderItem.Click += btnUPDATEOrderItem_Click;
            // 
            // btnDELETEOrderItem
            // 
            btnDELETEOrderItem.Location = new Point(582, 543);
            btnDELETEOrderItem.Name = "btnDELETEOrderItem";
            btnDELETEOrderItem.Size = new Size(150, 46);
            btnDELETEOrderItem.TabIndex = 8;
            btnDELETEOrderItem.Text = "DELETE";
            btnDELETEOrderItem.UseVisualStyleBackColor = true;
            btnDELETEOrderItem.Click += btnDELETEOrderItem_Click;
            // 
            // dataGridViewOrderItem
            // 
            dataGridViewOrderItem.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewOrderItem.Location = new Point(608, 175);
            dataGridViewOrderItem.Name = "dataGridViewOrderItem";
            dataGridViewOrderItem.RowHeadersWidth = 82;
            dataGridViewOrderItem.Size = new Size(700, 286);
            dataGridViewOrderItem.TabIndex = 9;
            // 
            // OrderItemForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1382, 705);
            Controls.Add(dataGridViewOrderItem);
            Controls.Add(btnDELETEOrderItem);
            Controls.Add(btnUPDATEOrderItem);
            Controls.Add(btnADDOrderItem);
            Controls.Add(textQuantity);
            Controls.Add(label3);
            Controls.Add(textItemId);
            Controls.Add(label2);
            Controls.Add(textOrdId);
            Controls.Add(label1);
            Name = "OrderItemForm";
            Text = "OrderItemForm";
            Load += OrderItemForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewOrderItem).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textOrdId;
        private TextBox textItemId;
        private Label label2;
        private TextBox textQuantity;
        private Label label3;
        private Button btnADDOrderItem;
        private Button btnUPDATEOrderItem;
        private Button btnDELETEOrderItem;
        private DataGridView dataGridViewOrderItem;
    }
}