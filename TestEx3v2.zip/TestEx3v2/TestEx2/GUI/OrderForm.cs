﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestEx3.DBOperations;
using TestEx3.Models;

namespace TestEx3
{
    public partial class OrderForm : Form
    {
        private OrderOperations orderOperations = new OrderOperations();
        public OrderForm()
        {
            InitializeComponent();
            LoadOrders();
        }

        private void LoadOrders()
        {
            dataGridViewOrders.DataSource = orderOperations.GetOrders();
        }
        private void OrderForm_Load(object sender, EventArgs e)
        {

        }

        private void btnADDOrder_Click(object sender, EventArgs e)
        {
            Order newOrder = new Order
            {
                Custid = int.Parse(textCustID.Text)
            };

            orderOperations.AddOrder(newOrder);
            LoadOrders();
            ClearOrderFields();
        }

        private void btnUPDATEOrder_Click(object sender, EventArgs e)
        {
            Order selectedOrder = GetSelectedRowOrder();

            if (selectedOrder != null)
            {
                selectedOrder.Custid = int.Parse(textCustID.Text);

                orderOperations.UpdateOrder(selectedOrder);
                LoadOrders();
                ClearOrderFields();
            }
            else
            {
                MessageBox.Show("Please select an order to update.");
            }
        }

        private void btnDELETEOrder_Click(object sender, EventArgs e)
        {
            Order selectedOrder = GetSelectedRowOrder();

            if (selectedOrder != null)
            {
                orderOperations.DeleteOrder(selectedOrder.OrderId);
                LoadOrders();
                ClearOrderFields();
            }
            else
            {
                MessageBox.Show("Please select an order to delete.");
            }
        }

        private Order GetSelectedRowOrder()
        {
            if (dataGridViewOrders.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridViewOrders.SelectedRows[0];
                return new Order
                {
                    OrderId = Convert.ToInt32(selectedRow.Cells["OrderId"].Value),
                    Custid = Convert.ToInt32(selectedRow.Cells["Custid"].Value)
                };
            }
            return null;
        }

        private void ClearOrderFields()
        {
            textCustID.Clear();
        }
    }
}
