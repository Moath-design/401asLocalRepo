﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestEx3.DBOperations;
using TestEx3.Models;

namespace TestEx3
{
    public partial class ItemForm : Form
    {
        private ItemOperations itemOperations = new ItemOperations();
        public ItemForm()
        {
            InitializeComponent();
            LoadItems();
        }

        private void ItemForm_Load(object sender, EventArgs e)
        {

        }
        private void LoadItems()
        {
            dataGridViewItems.DataSource = itemOperations.GetItems();
        }

        private void btnADDItem_Click(object sender, EventArgs e)
        {
            Item newItem = new Item
            {
                Name = textItemName.Text,
                Description = textItemDescription.Text,
                Price = decimal.Parse(textItemPrice.Text)
            };

            itemOperations.AddItem(newItem);
            LoadItems();
            ClearItemFields();
        }

        private void dataGridViewItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void btnUPDATEItem_Click(object sender, EventArgs e)
        {
            Item selectedItem = GetSelectedRowItem();

            if (selectedItem != null)
            {
                // Update the item with the modified data
                selectedItem.Name = textItemName.Text;
                selectedItem.Description = textItemDescription.Text;

                // Check if the input string for Price is not empty before attempting to parse
                if (!string.IsNullOrEmpty(textItemPrice.Text))
                {
                    decimal price;
                    if (decimal.TryParse(textItemPrice.Text, out price))
                    {
                        selectedItem.Price = price;

                        // Call the UpdateItem method from the ItemOperations class
                        itemOperations.UpdateItem(selectedItem);

                        // Reload the items in the DataGridView
                        LoadItems();
                        ClearItemFields();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Price format. Please enter a valid decimal value.");
                    }
                }
                else
                {
                    // Handle the case where the Price field is empty
                    MessageBox.Show("Please enter a value for Price.");
                }
            }
            else
            {
                MessageBox.Show("Please select an item to update.");
            }
        }

        private Item GetSelectedRowItem()
        {
            // Check if any row is selected
            if (dataGridViewItems.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridViewItems.SelectedRows[0];

                // Create a new Item object with the data from the selected row
                return new Item
                {
                    ItemId = Convert.ToInt32(selectedRow.Cells["Id"].Value),
                    Name = Convert.ToString(selectedRow.Cells["Name"].Value),
                    Description = Convert.ToString(selectedRow.Cells["Description"].Value),
                    Price = Convert.ToDecimal(selectedRow.Cells["Price"].Value)
                };
            }

            // If no row is selected, return null
            return null;
        }




        private void ClearItemFields()
        {
            textItemName.Clear();
            textItemDescription.Clear();
            textItemPrice.Clear();
        }

        

        private void btnDELETEItem_Click(object sender, EventArgs e)
        {
            Item selectedItem = GetSelectedRowItem();

            if (selectedItem != null)
            {
                itemOperations.DeleteItem(selectedItem.ItemId);
                LoadItems();
                ClearItemFields();
            }
            else
            {
                MessageBox.Show("Please select an item to delete.");
            }
        }
    }
}
