﻿namespace TestEx3
{
    partial class CustomerForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ADD = new Button();
            UPDATE = new Button();
            DELETE = new Button();
            label1 = new Label();
            txtCustId = new TextBox();
            txtFirstName = new TextBox();
            label2 = new Label();
            txtLastName = new TextBox();
            label3 = new Label();
            txtEmail = new TextBox();
            label4 = new Label();
            label5 = new Label();
            dateTimePickerDOB = new DateTimePicker();
            dataGridViewCustomers = new DataGridView();
            Go_To_ItemForm = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomers).BeginInit();
            SuspendLayout();
            // 
            // ADD
            // 
            ADD.Location = new Point(1258, 439);
            ADD.Name = "ADD";
            ADD.Size = new Size(167, 73);
            ADD.TabIndex = 0;
            ADD.Text = "ADD";
            ADD.UseVisualStyleBackColor = true;
            ADD.Click += ADD_Click;
            // 
            // UPDATE
            // 
            UPDATE.Location = new Point(993, 439);
            UPDATE.Name = "UPDATE";
            UPDATE.Size = new Size(167, 73);
            UPDATE.TabIndex = 1;
            UPDATE.Text = "UPDATE";
            UPDATE.UseVisualStyleBackColor = true;
            UPDATE.Click += UPDATE_Click;
            // 
            // DELETE
            // 
            DELETE.Location = new Point(704, 439);
            DELETE.Name = "DELETE";
            DELETE.Size = new Size(167, 73);
            DELETE.TabIndex = 2;
            DELETE.Text = "DELETE";
            DELETE.UseVisualStyleBackColor = true;
            DELETE.Click += DELETE_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(70, 98);
            label1.Name = "label1";
            label1.Size = new Size(49, 32);
            label1.TabIndex = 3;
            label1.Text = "ID: ";
            // 
            // txtCustId
            // 
            txtCustId.Location = new Point(237, 98);
            txtCustId.Name = "txtCustId";
            txtCustId.Size = new Size(299, 39);
            txtCustId.TabIndex = 4;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(237, 190);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(299, 39);
            txtFirstName.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(70, 190);
            label2.Name = "label2";
            label2.Size = new Size(141, 32);
            label2.TabIndex = 5;
            label2.Text = "First Nmae: ";
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(238, 297);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(299, 39);
            txtLastName.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(70, 297);
            label3.Name = "label3";
            label3.Size = new Size(138, 32);
            label3.TabIndex = 7;
            label3.Text = "Last Name: ";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(237, 400);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(299, 39);
            txtEmail.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(70, 400);
            label4.Name = "label4";
            label4.Size = new Size(83, 32);
            label4.TabIndex = 9;
            label4.Text = "Email: ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(70, 498);
            label5.Name = "label5";
            label5.Size = new Size(71, 32);
            label5.TabIndex = 11;
            label5.Text = "DoB: ";
            // 
            // dateTimePickerDOB
            // 
            dateTimePickerDOB.Location = new Point(237, 508);
            dateTimePickerDOB.Name = "dateTimePickerDOB";
            dateTimePickerDOB.Size = new Size(299, 39);
            dateTimePickerDOB.TabIndex = 12;
            // 
            // dataGridViewCustomers
            // 
            dataGridViewCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCustomers.Location = new Point(706, 75);
            dataGridViewCustomers.Name = "dataGridViewCustomers";
            dataGridViewCustomers.RowHeadersWidth = 82;
            dataGridViewCustomers.Size = new Size(708, 308);
            dataGridViewCustomers.TabIndex = 13;
            // 
            // Go_To_ItemForm
            // 
            Go_To_ItemForm.Location = new Point(721, 616);
            Go_To_ItemForm.Name = "Go_To_ItemForm";
            Go_To_ItemForm.Size = new Size(214, 75);
            Go_To_ItemForm.TabIndex = 14;
            Go_To_ItemForm.Text = "Go To Item Form";
            Go_To_ItemForm.UseVisualStyleBackColor = true;
            Go_To_ItemForm.Click += Go_To_ItemForm_Click;
            // 
            // CustomerForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1586, 757);
            Controls.Add(Go_To_ItemForm);
            Controls.Add(dataGridViewCustomers);
            Controls.Add(dateTimePickerDOB);
            Controls.Add(label5);
            Controls.Add(txtEmail);
            Controls.Add(label4);
            Controls.Add(txtLastName);
            Controls.Add(label3);
            Controls.Add(txtFirstName);
            Controls.Add(label2);
            Controls.Add(txtCustId);
            Controls.Add(label1);
            Controls.Add(DELETE);
            Controls.Add(UPDATE);
            Controls.Add(ADD);
            Name = "CustomerForm";
            Text = "CustomerForm";
            Load += CustomerForm_Load_1;
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomers).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button ADD;
        private Button UPDATE;
        private Button DELETE;
        private Label label1;
        private TextBox txtCustId;
        private TextBox txtFirstName;
        private Label label2;
        private TextBox txtLastName;
        private Label label3;
        private TextBox txtEmail;
        private Label label4;
        private Label label5;
        private DateTimePicker dateTimePickerDOB;
        private DataGridView dataGridViewCustomers;
        private Button Go_To_ItemForm;
    }
}
