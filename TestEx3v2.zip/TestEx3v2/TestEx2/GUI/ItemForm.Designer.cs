﻿namespace TestEx3
{
    partial class ItemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textItemID = new TextBox();
            textItemName = new TextBox();
            label2 = new Label();
            textItemDescription = new TextBox();
            label3 = new Label();
            textItemPrice = new TextBox();
            label4 = new Label();
            btnADDItem = new Button();
            btnUPDATEItem = new Button();
            btnDELETEItem = new Button();
            dataGridViewItems = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewItems).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(48, 86);
            label1.Name = "label1";
            label1.Size = new Size(42, 32);
            label1.TabIndex = 0;
            label1.Text = "ID:";
            // 
            // textItemID
            // 
            textItemID.Location = new Point(212, 79);
            textItemID.Name = "textItemID";
            textItemID.Size = new Size(200, 39);
            textItemID.TabIndex = 1;
            // 
            // textItemName
            // 
            textItemName.Location = new Point(212, 163);
            textItemName.Name = "textItemName";
            textItemName.Size = new Size(200, 39);
            textItemName.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(48, 170);
            label2.Name = "label2";
            label2.Size = new Size(90, 32);
            label2.TabIndex = 2;
            label2.Text = "Name: ";
            // 
            // textItemDescription
            // 
            textItemDescription.Location = new Point(212, 249);
            textItemDescription.Name = "textItemDescription";
            textItemDescription.Size = new Size(200, 39);
            textItemDescription.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 256);
            label3.Name = "label3";
            label3.Size = new Size(135, 32);
            label3.TabIndex = 4;
            label3.Text = "Description";
            // 
            // textItemPrice
            // 
            textItemPrice.Location = new Point(212, 335);
            textItemPrice.Name = "textItemPrice";
            textItemPrice.Size = new Size(200, 39);
            textItemPrice.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(48, 342);
            label4.Name = "label4";
            label4.Size = new Size(77, 32);
            label4.TabIndex = 6;
            label4.Text = "Price: ";
            // 
            // btnADDItem
            // 
            btnADDItem.Location = new Point(1090, 552);
            btnADDItem.Name = "btnADDItem";
            btnADDItem.Size = new Size(150, 46);
            btnADDItem.TabIndex = 8;
            btnADDItem.Text = "ADD";
            btnADDItem.UseVisualStyleBackColor = true;
            btnADDItem.Click += btnADDItem_Click;
            // 
            // btnUPDATEItem
            // 
            btnUPDATEItem.Location = new Point(843, 552);
            btnUPDATEItem.Name = "btnUPDATEItem";
            btnUPDATEItem.Size = new Size(150, 46);
            btnUPDATEItem.TabIndex = 9;
            btnUPDATEItem.Text = "UPDATE";
            btnUPDATEItem.UseVisualStyleBackColor = true;
            btnUPDATEItem.Click += btnUPDATEItem_Click;
            // 
            // btnDELETEItem
            // 
            btnDELETEItem.Location = new Point(575, 552);
            btnDELETEItem.Name = "btnDELETEItem";
            btnDELETEItem.Size = new Size(150, 46);
            btnDELETEItem.TabIndex = 10;
            btnDELETEItem.Text = "DELETE";
            btnDELETEItem.UseVisualStyleBackColor = true;
            btnDELETEItem.Click += btnDELETEItem_Click;
            // 
            // dataGridViewItems
            // 
            dataGridViewItems.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewItems.Location = new Point(625, 170);
            dataGridViewItems.Name = "dataGridViewItems";
            dataGridViewItems.RowHeadersWidth = 82;
            dataGridViewItems.Size = new Size(609, 284);
            dataGridViewItems.TabIndex = 11;
            dataGridViewItems.CellContentClick += dataGridViewItems_CellContentClick;
            // 
            // ItemForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1340, 709);
            Controls.Add(dataGridViewItems);
            Controls.Add(btnDELETEItem);
            Controls.Add(btnUPDATEItem);
            Controls.Add(btnADDItem);
            Controls.Add(textItemPrice);
            Controls.Add(label4);
            Controls.Add(textItemDescription);
            Controls.Add(label3);
            Controls.Add(textItemName);
            Controls.Add(label2);
            Controls.Add(textItemID);
            Controls.Add(label1);
            Name = "ItemForm";
            Text = "ItemForm";
            Load += ItemForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewItems).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textItemID;
        private TextBox textItemName;
        private Label label2;
        private TextBox textItemDescription;
        private Label label3;
        private TextBox textItemPrice;
        private Label label4;
        private Button btnADDItem;
        private Button btnUPDATEItem;
        private Button btnDELETEItem;
        private DataGridView dataGridViewItems;
    }
}