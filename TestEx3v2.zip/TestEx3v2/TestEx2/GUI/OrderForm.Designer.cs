﻿namespace TestEx3
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textOrderID = new TextBox();
            textCustID = new TextBox();
            btnADDOrder = new Button();
            btnUPDATEOrder = new Button();
            btnDELETEOrder = new Button();
            dataGridViewOrders = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewOrders).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(98, 134);
            label1.Name = "label1";
            label1.Size = new Size(110, 32);
            label1.TabIndex = 0;
            label1.Text = "Order ID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(98, 211);
            label2.Name = "label2";
            label2.Size = new Size(152, 32);
            label2.TabIndex = 1;
            label2.Text = "Customer ID:";
            // 
            // textOrderID
            // 
            textOrderID.Location = new Point(286, 134);
            textOrderID.Name = "textOrderID";
            textOrderID.Size = new Size(200, 39);
            textOrderID.TabIndex = 2;
            // 
            // textCustID
            // 
            textCustID.Location = new Point(286, 211);
            textCustID.Name = "textCustID";
            textCustID.Size = new Size(200, 39);
            textCustID.TabIndex = 3;
            // 
            // btnADDOrder
            // 
            btnADDOrder.Location = new Point(1275, 506);
            btnADDOrder.Name = "btnADDOrder";
            btnADDOrder.Size = new Size(150, 46);
            btnADDOrder.TabIndex = 4;
            btnADDOrder.Text = "ADD";
            btnADDOrder.UseVisualStyleBackColor = true;
            btnADDOrder.Click += btnADDOrder_Click;
            // 
            // btnUPDATEOrder
            // 
            btnUPDATEOrder.Location = new Point(1037, 506);
            btnUPDATEOrder.Name = "btnUPDATEOrder";
            btnUPDATEOrder.Size = new Size(150, 46);
            btnUPDATEOrder.TabIndex = 5;
            btnUPDATEOrder.Text = "UPDATE";
            btnUPDATEOrder.UseVisualStyleBackColor = true;
            btnUPDATEOrder.Click += btnUPDATEOrder_Click;
            // 
            // btnDELETEOrder
            // 
            btnDELETEOrder.Location = new Point(787, 506);
            btnDELETEOrder.Name = "btnDELETEOrder";
            btnDELETEOrder.Size = new Size(150, 46);
            btnDELETEOrder.TabIndex = 6;
            btnDELETEOrder.Text = "DELETE";
            btnDELETEOrder.UseVisualStyleBackColor = true;
            btnDELETEOrder.Click += btnDELETEOrder_Click;
            // 
            // dataGridViewOrders
            // 
            dataGridViewOrders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewOrders.Location = new Point(757, 164);
            dataGridViewOrders.Name = "dataGridViewOrders";
            dataGridViewOrders.RowHeadersWidth = 82;
            dataGridViewOrders.Size = new Size(665, 254);
            dataGridViewOrders.TabIndex = 7;
            // 
            // OrderForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1473, 628);
            Controls.Add(dataGridViewOrders);
            Controls.Add(btnDELETEOrder);
            Controls.Add(btnUPDATEOrder);
            Controls.Add(btnADDOrder);
            Controls.Add(textCustID);
            Controls.Add(textOrderID);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "OrderForm";
            Text = "OrderForm";
            Load += OrderForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewOrders).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textOrderID;
        private TextBox textCustID;
        private Button btnADDOrder;
        private Button btnUPDATEOrder;
        private Button btnDELETEOrder;
        private DataGridView dataGridViewOrders;
    }
}