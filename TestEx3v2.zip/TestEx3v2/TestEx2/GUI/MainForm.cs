﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestEx3.GUI
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void GoToCustForm_Click(object sender, EventArgs e)
        {
            // Create an instance of the CustomerForm
            CustomerForm customerForm = new CustomerForm();

            // Show the CustomerForm
            customerForm.Show();

            //  Hide the main form
            Hide();
        }

        private void GoToItemsForm_Click(object sender, EventArgs e)
        {
            // Create an instance of the ItemForm
            ItemForm itemForm = new ItemForm();

            // Show the ItemForm
            itemForm.Show();

            //  Hide the main form
            Hide();
        }

        private void GoToOrdersForm_Click(object sender, EventArgs e)
        {
            // Create an instance of the OrderForm
            OrderForm orderForm = new OrderForm();

            // Show the OrderForm
            orderForm.Show();
            // Hide the main form
            Hide();
        }

        private void GoToOrderItemsForm_Click(object sender, EventArgs e)
        {
            // Create an instance of the OrderForm
            OrderItemForm orderForm = new OrderItemForm();

            // Show the OrderForm
            orderForm.Show();
            // Hide the main form
            Hide();
        }
    }
}
