using TestEx3.DBOperations;
using TestEx3.Models;

namespace TestEx3
{
    public partial class CustomerForm : Form
    {
        private CustomerOperations customerOperations = new CustomerOperations();

        //public static object Control { get; internal set; }

        public CustomerForm()
        {
            InitializeComponent();
        }

        private void ADD_Click(object sender, EventArgs e)
        {
            Customer newCustomer = new Customer
            {
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                Email = txtEmail.Text,
                DateOfBirth = dateTimePickerDOB.Value
            };

            customerOperations.AddCustomer(newCustomer);
            LoadCustomers();
        }

        
        private void LoadCustomers()
        {
            dataGridViewCustomers.DataSource = customerOperations.GetCustomers();
        }

        private void UPDATE_Click(object sender, EventArgs e)
        {
            if (dataGridViewCustomers.SelectedRows.Count > 0)
            {
                Customer selectedCustomer = GetSelectedRowCustomer();

                if (selectedCustomer != null)
                {
                    selectedCustomer.FirstName = txtFirstName.Text;
                    selectedCustomer.LastName = txtLastName.Text;
                    selectedCustomer.Email = txtEmail.Text;
                    selectedCustomer.DateOfBirth = dateTimePickerDOB.Value;

                    customerOperations.UpdateCustomer(selectedCustomer);
                    LoadCustomers();
                    ClearCustomerFields();
                }
                else
                {
                    MessageBox.Show("Please select a customer to update.");
                }
            }
            else
            {
                MessageBox.Show("Please select a customer to update.");
            }
        }

        private Customer GetSelectedRowCustomer()
        {
            if (dataGridViewCustomers.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridViewCustomers.SelectedRows[0];
                return new Customer
                {
                    Id = Convert.ToInt32(selectedRow.Cells["CustId"].Value),
                    FirstName = Convert.ToString(selectedRow.Cells["FirstName"].Value),
                    LastName = Convert.ToString(selectedRow.Cells["LastName"].Value),
                    Email = Convert.ToString(selectedRow.Cells["Email"].Value),
                    DateOfBirth = Convert.ToDateTime(selectedRow.Cells["DateOfBirth"].Value)
                };
            }

            return null;
        }

        private void DELETE_Click(object sender, EventArgs e)
        {
            if (dataGridViewCustomers.SelectedRows.Count > 0)
            {
                int CustomerId = GetSelectedRowCustomerId();

                if (CustomerId != -1)
                {
                    customerOperations.DeleteCustomer(CustomerId);
                    LoadCustomers();
                    ClearCustomerFields();
                }
                else
                {
                    MessageBox.Show("Please select a customer to delete.");
                }
            }
            else
            {
                MessageBox.Show("Please select a customer to delete.");
            }
        }

        private void Go_To_ItemForm_Click(object sender, EventArgs e)
        {
            ItemForm ItemForm = new ItemForm();
            ItemForm.Show();

        }

        private void CustomerForm_Load_1(object sender, EventArgs e)
        {
            LoadCustomers();
        }

        private void ClearItemFields()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            dateTimePickerDOB.Text ="";
        }

        

        private int GetSelectedRowCustomerId()
        {
            if (dataGridViewCustomers.SelectedRows.Count > 0)
            {
                return Convert.ToInt32(dataGridViewCustomers.SelectedRows[0].Cells["CustId"].Value);
            }

            return -1;
        }

        private void ClearCustomerFields()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtEmail.Clear();
            dateTimePickerDOB.Value = DateTime.Now;
        }
    }
}
