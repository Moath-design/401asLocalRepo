﻿namespace TestEx3.GUI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            GoToCustForm = new Button();
            GoToItemsForm = new Button();
            GoToOrdersForm = new Button();
            GoToOrderItemsForm = new Button();
            SuspendLayout();
            // 
            // GoToCustForm
            // 
            GoToCustForm.Location = new Point(635, 90);
            GoToCustForm.Name = "GoToCustForm";
            GoToCustForm.Size = new Size(179, 100);
            GoToCustForm.TabIndex = 0;
            GoToCustForm.Text = "Customer Form";
            GoToCustForm.UseVisualStyleBackColor = true;
            GoToCustForm.Click += GoToCustForm_Click;
            // 
            // GoToItemsForm
            // 
            GoToItemsForm.Location = new Point(175, 90);
            GoToItemsForm.Name = "GoToItemsForm";
            GoToItemsForm.Size = new Size(179, 100);
            GoToItemsForm.TabIndex = 1;
            GoToItemsForm.Text = "Items Form";
            GoToItemsForm.UseVisualStyleBackColor = true;
            GoToItemsForm.Click += GoToItemsForm_Click;
            // 
            // GoToOrdersForm
            // 
            GoToOrdersForm.Location = new Point(635, 279);
            GoToOrdersForm.Name = "GoToOrdersForm";
            GoToOrdersForm.Size = new Size(179, 100);
            GoToOrdersForm.TabIndex = 2;
            GoToOrdersForm.Text = "Orders Form";
            GoToOrdersForm.UseVisualStyleBackColor = true;
            GoToOrdersForm.Click += GoToOrdersForm_Click;
            // 
            // GoToOrderItemsForm
            // 
            GoToOrderItemsForm.Location = new Point(175, 269);
            GoToOrderItemsForm.Name = "GoToOrderItemsForm";
            GoToOrderItemsForm.Size = new Size(179, 100);
            GoToOrderItemsForm.TabIndex = 3;
            GoToOrderItemsForm.Text = "Order Items Form";
            GoToOrderItemsForm.UseVisualStyleBackColor = true;
            GoToOrderItemsForm.Click += GoToOrderItemsForm_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1051, 528);
            Controls.Add(GoToOrderItemsForm);
            Controls.Add(GoToOrdersForm);
            Controls.Add(GoToItemsForm);
            Controls.Add(GoToCustForm);
            Name = "MainForm";
            Text = "MainForm";
            ResumeLayout(false);
        }

        #endregion

        private Button GoToCustForm;
        private Button GoToItemsForm;
        private Button GoToOrdersForm;
        private Button GoToOrderItemsForm;
    }
}