﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestEx3.DBOperations;
using TestEx3.Models;

namespace TestEx3
{

    public partial class OrderItemForm : Form
    {
        private OrderItemOperations orderItemOperations = new OrderItemOperations();
        public OrderItemForm()
        {
            InitializeComponent();
            LoadOrderItems();
        }

        private void LoadOrderItems()
        {
            dataGridViewOrderItem.DataSource = orderItemOperations.GetOrderItems();
        }
        private void OrderItemForm_Load(object sender, EventArgs e)
        {

        }

        private void btnADDOrderItem_Click(object sender, EventArgs e)
        {
            OrderItem newOrderItem = new OrderItem
            {
                OrderId = int.Parse(textOrdId.Text),
                ItemId = int.Parse(textItemId.Text),
                Quantity = int.Parse(textQuantity.Text)
            };

            orderItemOperations.AddOrderItem(newOrderItem);
            LoadOrderItems();
            ClearOrderItemFields();
        }

        private void btnUPDATEOrderItem_Click(object sender, EventArgs e)
        {
            if (dataGridViewOrderItem.SelectedRows.Count > 0)
            {
                OrderItem selectedOrderItem = GetSelectedRowOrderItem();

                if (selectedOrderItem != null)
                {
                    // Display a dialog or input box for the user to enter the new quantity
                    string newQuantityInput = Interaction.InputBox("Enter the new quantity:", "Update Quantity", selectedOrderItem.Quantity.ToString());

                    if (int.TryParse(newQuantityInput, out int newQuantity))
                    {
                        // Update only the Quantity field
                        selectedOrderItem.Quantity = newQuantity;

                        // Call the UpdateOrderItem method in your OrderItemOperations class
                        orderItemOperations.UpdateOrderItem(selectedOrderItem);

                        // Reload the data in the DataGridView
                        LoadOrderItems();
                        ClearOrderItemFields();
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid quantity.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an order item to update.");
            }
        }

        private void btnDELETEOrderItem_Click(object sender, EventArgs e)
        {
            if (dataGridViewOrderItem.SelectedRows.Count > 0)
            {
                OrderItem selectedOrderItem = GetSelectedRowOrderItem();

                if (selectedOrderItem != null)
                {
                    // Display a confirmation dialog before proceeding with deletion
                    DialogResult result = MessageBox.Show("Are you sure you want to delete this order item?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        // Call the DeleteOrderItem method in your OrderItemOperations class
                        orderItemOperations.DeleteOrderItem(selectedOrderItem.OrderId, selectedOrderItem.ItemId);

                        // Reload the data in the DataGridView
                        LoadOrderItems();
                        ClearOrderItemFields();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an order item to delete.");
            }
        }

        private OrderItem GetSelectedRowOrderItem()
        {
            if (dataGridViewOrderItem.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridViewOrderItem.SelectedRows[0];
                return new OrderItem
                {
                    //OrderItemId = Convert.ToInt32(selectedRow.Cells["OrderItemId"].Value),
                    OrderId = Convert.ToInt32(selectedRow.Cells["OrderId"].Value),
                    ItemId = Convert.ToInt32(selectedRow.Cells["ItemId"].Value),
                    Quantity = Convert.ToInt32(selectedRow.Cells["Quantity"].Value)
                };
            }

            return null;
        }

        private int GetSelectedRowOrderItemId()
        {
            if (dataGridViewOrderItem.SelectedRows.Count > 0)
            {
                return Convert.ToInt32(dataGridViewOrderItem.SelectedRows[0].Cells["OrderItemId"].Value);
            }

            return -1;
        }

        private void ClearOrderItemFields()
        {
            textOrdId.Clear();
            textItemId.Clear();
            textQuantity.Clear();
        }
    }
}
